#Fallout
ShitPaste, Newest Fallout-Version which was built into RedEngine. Leaked by discord.gg/8888.
